# Chapter 7 Support Vector Machines Dash App
