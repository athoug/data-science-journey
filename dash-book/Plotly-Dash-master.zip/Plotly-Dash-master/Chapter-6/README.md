# wealthdashboard.app

This repo is for  [wealthdashboard.app](https://www.wealthdashboard.app/). 

![asset_allocation](https://user-images.githubusercontent.com/72614349/103412086-bf019f00-4b30-11eb-8420-d3b128b673dc.png)
